How to run the Student Management System (StudentMS) Project


1.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

2. Open PHPMyAdmin (http://localhost/phpmyadmin)

3. Create a database with name studentmsdb

4. Import studentmsdb.sql file.

5.Run the script http://localhost/studentms (frontend)


Credential for admin panel :

Username: admin
Password: Test@123

Credential for Student / User panel :

Username: anujk3
Password: Test@123

Or Register a new Student/User.